@extends('layouts.admin.main')

@section('title', 'Tambah Potensi Kuliner')

@section('content')
    <h1 class="h3 mb-2 text-gray-800">Tambah Potensi Kuliner</h1>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Tambah Potensi Kuliner</h6>
        </div>
        <div class="card-body">
            <form action="{{ route('admin.potensi-kuliner.store') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="form-group">
                    <label for="nama_tempat">Nama Tempat</label>
                    <input type="text" class="form-control" id="nama_tempat" name="nama_tempat"
                        value="{{ old('nama_tempat') }}" required>
                    @error('nama_tempat')
                        <div class="text-danger">{{ $message }}</div>
                    @enderror
                </div>

                <div class="form-group">
                    <label for="deskripsi">Deskripsi</label>
                    <textarea class="form-control" id="deskripsi" name="deskripsi" required>{{ old('deskripsi') }}</textarea>
                    @error('deskripsi')
                        <div class="text-danger">{{ $message }}</div>
                    @enderror
                </div>

                <div class="form-group">
                    <label for="lokasi">Lokasi</label>
                    <input type="text" class="form-control" id="lokasi" name="lokasi" value="{{ old('lokasi') }}"
                        required>
                    @error('lokasi')
                        <div class="text-danger">{{ $message }}</div>
                    @enderror
                </div>

                <div class="form-group">
                    <label for="kontak">Kontak</label>
                    <input type="text" class="form-control" id="kontak" name="kontak" value="{{ old('kontak') }}"
                        required>
                    @error('kontak')
                        <div class="text-danger">{{ $message }}</div>
                    @enderror
                </div>

                <div class="form-group">
                    <label for="kisaran_harga">Kisaran Harga</label>
                    <input type="text" class="form-control" id="kisaran_harga" name="kisaran_harga"
                        value="{{ old('kisaran_harga') }}" required>
                    @error('kisaran_harga')
                        <div class="text-danger">{{ $message }}</div>
                    @enderror
                </div>

                <div class="form-group">
                    <label for="masakan">Masakan</label>
                    <input type="text" class="form-control" id="masakan" name="masakan" value="{{ old('masakan') }}"
                        required>
                    @error('masakan')
                        <div class="text-danger">{{ $message }}</div>
                    @enderror
                </div>

                <div class="form-group">
                    <label for="makanan">Makanan</label>
                    <input type="text" class="form-control" id="makanan" name="makanan" value="{{ old('makanan') }}"
                        required>
                    @error('makanan')
                        <div class="text-danger">{{ $message }}</div>
                    @enderror
                </div>

                <div class="form-group">
                    <label for="fitur">Fitur</label>
                    <textarea class="form-control class="form-control" id="fitur" name="fitur" value="{{ old('fitur') }}" required> </textarea>
                    @error('fitur')
                        <div class="text-danger">{{ $message }}</div>
                    @enderror
                </div>

                <div class="form-group">
                    <label for="gambar">Upload Gambar (Harus 3 gambar) & Ukuran maks 10MB</label>
                    <input type="file" class="form-control-file" id="gambar" name="gambar[]" multiple required>
                    @error('gambar')
                        <div class="text-danger">{{ $message }}</div>
                    @enderror
                </div>

                <div class="text-right">
                    <a href="{{ route('admin.potensi-kuliner.index') }}" class="btn btn-danger">
                        <i class="fas fa-arrow-left"></i> Kembali
                    </a>
                    <button type="submit" class="btn btn-success">
                        <i class="fa fa-plus"></i> Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>
@endsection
